import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Minutes — meeting notes, kept",
  description:
    "Paste a transcript, get a clean summary and action items in seconds. A permanent record of every meeting, filed automatically.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">{children}</body>
    </html>
  );
}
