import Link from "next/link";
import { Logo } from "@/components/Logo";
import { AuthForm } from "@/components/AuthForm";

export const metadata = { title: "Log in — Minutes" };

export default function LoginPage() {
  return (
    <div className="flex min-h-full flex-1 flex-col items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <h1 className="mb-1 text-center font-display text-2xl text-text">
          Welcome back
        </h1>
        <p className="mb-8 text-center text-sm text-text-muted">
          Log in to see your meeting history.
        </p>
        <AuthForm mode="login" />
        <p className="mt-6 text-center text-sm text-text-muted">
          New here?{" "}
          <Link href="/signup" className="text-brass hover:text-brass-bright">
            Create a free account
          </Link>
        </p>
      </div>
    </div>
  );
}
