import Link from "next/link";
import { Logo } from "@/components/Logo";
import { AuthForm } from "@/components/AuthForm";

export const metadata = { title: "Start free — Minutes" };

export default function SignupPage() {
  return (
    <div className="flex min-h-full flex-1 flex-col items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <h1 className="mb-1 text-center font-display text-2xl text-text">
          Start for free
        </h1>
        <p className="mb-8 text-center text-sm text-text-muted">
          3 meeting write-ups a day, no card required.
        </p>
        <AuthForm mode="signup" />
        <p className="mt-6 text-center text-sm text-text-muted">
          Already have an account?{" "}
          <Link href="/login" className="text-brass hover:text-brass-bright">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
