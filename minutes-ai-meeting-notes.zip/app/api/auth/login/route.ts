import { NextResponse } from "next/server";
import { loginSchema, firstIssueMessage } from "@/lib/validation";
import { getUserByEmail, toPublicUser } from "@/lib/users";
import { verifyPassword, createSession } from "@/lib/auth";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: firstIssueMessage(parsed.error) },
      { status: 400 }
    );
  }

  const { email, password } = parsed.data;
  const user = await getUserByEmail(email);

  // Same generic message whether the email or the password was wrong, so a
  // caller can't use this endpoint to enumerate which emails have accounts.
  const invalid = () =>
    NextResponse.json({ error: "Incorrect email or password." }, { status: 401 });

  if (!user) return invalid();

  const valid = await verifyPassword(password, user.password_hash);
  if (!valid) return invalid();

  await createSession(user.id);
  return NextResponse.json({ user: toPublicUser(user) });
}
