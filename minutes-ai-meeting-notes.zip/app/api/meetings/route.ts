import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { createMeetingSchema, firstIssueMessage } from "@/lib/validation";
import { listMeetingsForUser, createMeeting } from "@/lib/meetings";
import { getUsageStatus } from "@/lib/plan";
import { generateMeetingNotes } from "@/lib/anthropic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  }
  const meetings = await listMeetingsForUser(user.id);
  return NextResponse.json({ meetings });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  }

  const usage = await getUsageStatus(user);
  if (!usage.canCreate) {
    return NextResponse.json(
      {
        error: `You've used all ${usage.limit} free write-ups for today. Upgrade to Pro for unlimited.`,
        code: "LIMIT_REACHED",
      },
      { status: 402 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const parsed = createMeetingSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: firstIssueMessage(parsed.error) },
      { status: 400 }
    );
  }

  let notes;
  try {
    notes = await generateMeetingNotes(parsed.data.transcript);
  } catch (err) {
    console.error("generateMeetingNotes failed:", err);
    return NextResponse.json(
      {
        error:
          "Couldn't generate notes for that transcript. Please try again in a moment.",
      },
      { status: 502 }
    );
  }

  const meeting = await createMeeting(user.id, parsed.data.transcript, notes);
  return NextResponse.json({ meeting }, { status: 201 });
}
