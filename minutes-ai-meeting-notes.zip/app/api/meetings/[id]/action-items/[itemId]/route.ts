import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { toggleActionItem } from "@/lib/meetings";

export async function PATCH(
  _request: Request,
  { params }: { params: Promise<{ id: string; itemId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  }

  const { itemId } = await params;
  const item = await toggleActionItem(itemId, user.id);
  if (!item) {
    return NextResponse.json({ error: "Action item not found." }, { status: 404 });
  }

  return NextResponse.json({ item });
}
