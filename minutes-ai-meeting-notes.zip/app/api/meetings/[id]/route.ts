import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getMeetingWithItems } from "@/lib/meetings";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  }

  const { id } = await params;
  const meeting = await getMeetingWithItems(id, user.id);
  if (!meeting) {
    return NextResponse.json({ error: "Meeting not found." }, { status: 404 });
  }

  return NextResponse.json({ meeting });
}
