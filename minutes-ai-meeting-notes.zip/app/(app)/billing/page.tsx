import { getCurrentUser } from "@/lib/auth";
import { PLANS } from "@/lib/plan";
import { BillingActionButton } from "@/components/BillingActionButton";

export const metadata = { title: "Billing — Minutes" };

export default async function BillingPage({
  searchParams,
}: {
  searchParams: Promise<{ checkout?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null; // AppLayout already redirects.

  const { checkout } = await searchParams;
  const plan = PLANS[user.plan];

  return (
    <div className="max-w-xl">
      <h1 className="font-display text-2xl text-text">Billing</h1>

      {checkout === "success" && (
        <p className="mt-4 rounded-sm border border-good/40 bg-good/10 px-4 py-3 text-sm text-good">
          You&apos;re on Pro. Thanks for upgrading — unlimited write-ups are
          unlocked.
        </p>
      )}
      {checkout === "cancelled" && (
        <p className="mt-4 rounded-sm border border-rule px-4 py-3 text-sm text-text-muted">
          Checkout was cancelled — you&apos;re still on {plan.label}.
        </p>
      )}

      <div className="mt-8 rounded-sm border border-rule bg-ink-raised p-6">
        <p className="font-mono text-xs uppercase tracking-widest text-brass">
          Current plan
        </p>
        <p className="mt-2 font-display text-xl text-text">
          {plan.label} · <span className="font-mono text-base">{plan.priceLabel}</span>
        </p>

        {user.plan === "pro" && user.stripe_current_period_end && (
          <p className="mt-2 text-sm text-text-muted">
            {user.stripe_subscription_status === "active"
              ? "Renews"
              : "Ends"}{" "}
            {new Date(user.stripe_current_period_end).toLocaleDateString(undefined, {
              dateStyle: "long",
            })}
            .
          </p>
        )}

        <ul className="mt-5 space-y-2 text-sm text-text-muted">
          {plan.features.map((f) => (
            <li key={f}>· {f}</li>
          ))}
        </ul>

        <div className="mt-6">
          {user.plan === "pro" ? (
            <BillingActionButton endpoint="/api/stripe/portal" variant="secondary">
              Manage subscription
            </BillingActionButton>
          ) : (
            <BillingActionButton endpoint="/api/stripe/checkout">
              Upgrade to Pro — {PLANS.pro.priceLabel}
            </BillingActionButton>
          )}
        </div>
      </div>

      {user.plan === "pro" && (
        <p className="mt-4 text-sm text-text-muted">
          Manage subscription opens Stripe&apos;s billing portal, where you can
          update your card or cancel anytime.
        </p>
      )}
    </div>
  );
}
