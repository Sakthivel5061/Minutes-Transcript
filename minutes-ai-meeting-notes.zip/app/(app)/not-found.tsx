import Link from "next/link";

export default function AppNotFound() {
  return (
    <div className="py-16 text-center">
      <p className="font-mono text-xs uppercase tracking-widest text-brass">
        Not found
      </p>
      <h1 className="mt-3 font-display text-2xl text-text">
        That page isn&apos;t on file.
      </h1>
      <p className="mt-2 text-sm text-text-muted">
        It may have been moved, or it belongs to a different account.
      </p>
      <Link
        href="/dashboard"
        className="mt-6 inline-block text-sm text-brass hover:text-brass-bright"
      >
        Back to dashboard
      </Link>
    </div>
  );
}
