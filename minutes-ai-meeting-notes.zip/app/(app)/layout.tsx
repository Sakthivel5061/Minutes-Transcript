import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { LogoutButton } from "@/components/LogoutButton";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // The real access check for every authenticated route. Middleware only
  // handles redirect UX (see middleware.ts) — this is the boundary that
  // actually matters.
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-full flex-col">
      <header className="border-b border-rule">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-8">
            <Logo />
            <nav className="flex items-center gap-5 text-sm">
              <Link href="/dashboard" className="text-text-muted hover:text-text">
                Dashboard
              </Link>
              <Link href="/billing" className="text-text-muted hover:text-text">
                Billing
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden font-mono text-xs uppercase tracking-wide text-text-muted sm:inline">
              {user.plan === "pro" ? "Pro plan" : "Starter plan"}
            </span>
            <LogoutButton />
          </div>
        </div>
      </header>
      <main className="flex-1">
        <div className="mx-auto max-w-5xl px-6 py-10">{children}</div>
      </main>
    </div>
  );
}
