import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { getMeetingWithItems } from "@/lib/meetings";
import { ActionItemChecklist } from "@/components/ActionItemChecklist";

export default async function MeetingDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) return null; // AppLayout already redirects.

  const { id } = await params;
  const meeting = await getMeetingWithItems(id, user.id);
  if (!meeting) notFound();

  return (
    <div className="max-w-2xl">
      <Link
        href="/dashboard"
        className="inline-flex items-center gap-1.5 text-sm text-text-muted hover:text-text"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to history
      </Link>

      <h1 className="mt-5 font-display text-2xl text-text">{meeting.title}</h1>
      <p className="mt-1 font-mono text-xs text-text-muted">
        {new Date(meeting.created_at).toLocaleString(undefined, {
          dateStyle: "medium",
          timeStyle: "short",
        })}
      </p>

      <section className="mt-8">
        <h2 className="font-mono text-xs uppercase tracking-widest text-brass">
          Summary
        </h2>
        <p className="mt-3 leading-relaxed text-text">{meeting.summary}</p>
      </section>

      <section className="mt-8">
        <h2 className="font-mono text-xs uppercase tracking-widest text-brass">
          Action items
        </h2>
        <div className="mt-3">
          <ActionItemChecklist meetingId={meeting.id} items={meeting.action_items} />
        </div>
      </section>

      <details className="mt-10 rounded-sm border border-rule">
        <summary className="cursor-pointer px-4 py-3 text-sm text-text-muted hover:text-text">
          View original transcript
        </summary>
        <pre className="max-h-96 overflow-auto whitespace-pre-wrap border-t border-rule px-4 py-3 font-mono text-[0.8rem] leading-relaxed text-text-muted">
          {meeting.transcript}
        </pre>
      </details>
    </div>
  );
}
