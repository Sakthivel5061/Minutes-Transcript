import Link from "next/link";
import { FileText } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { getUsageStatus } from "@/lib/plan";
import { listMeetingsForUser } from "@/lib/meetings";
import { NewMeetingForm } from "@/components/NewMeetingForm";
import { LinkButton } from "@/components/Button";

export const metadata = { title: "Dashboard — Minutes" };

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) return null; // AppLayout already redirects; this satisfies TS.

  const [usage, meetings] = await Promise.all([
    getUsageStatus(user),
    listMeetingsForUser(user.id),
  ]);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-2xl text-text">New meeting</h1>
        <p className="mt-1 text-sm text-text-muted">
          {usage.limit === null
            ? "Unlimited write-ups on Pro."
            : `${usage.used} of ${usage.limit} free write-ups used today.`}
        </p>
      </div>

      {usage.canCreate ? (
        <NewMeetingForm />
      ) : (
        <div className="rounded-sm border border-brass/40 bg-ink-raised p-6">
          <p className="text-text">
            You&apos;ve used all {usage.limit} free write-ups for today.
          </p>
          <p className="mt-1 text-sm text-text-muted">
            They reset at midnight, or upgrade to Pro for unlimited write-ups
            right now.
          </p>
          <LinkButton href="/billing" className="mt-4">
            Upgrade to Pro
          </LinkButton>
        </div>
      )}

      <div>
        <h2 className="font-display text-xl text-text">History</h2>
        {meetings.length === 0 ? (
          <p className="mt-3 text-sm text-text-muted">
            Nothing here yet — generate your first write-up above.
          </p>
        ) : (
          <ul className="mt-4 divide-y divide-rule border-y border-rule">
            {meetings.map((m) => (
              <li key={m.id}>
                <Link
                  href={`/dashboard/${m.id}`}
                  className="flex items-center gap-3 py-4 hover:bg-ink-raised/60"
                >
                  <FileText className="h-4 w-4 flex-shrink-0 text-brass" />
                  <span className="flex-1 truncate text-text">{m.title}</span>
                  <span className="flex-shrink-0 font-mono text-xs text-text-muted">
                    {new Date(m.created_at).toLocaleDateString(undefined, {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
