import Link from "next/link";
import { Logo } from "@/components/Logo";

export default function NotFound() {
  return (
    <div className="flex min-h-full flex-1 flex-col items-center justify-center px-6 py-16 text-center">
      <Logo className="mb-8" />
      <p className="font-mono text-xs uppercase tracking-widest text-brass">
        404
      </p>
      <h1 className="mt-3 font-display text-2xl text-text">
        That page isn&apos;t on file.
      </h1>
      <Link
        href="/"
        className="mt-6 inline-block text-sm text-brass hover:text-brass-bright"
      >
        Back home
      </Link>
    </div>
  );
}
