import {
  ClipboardPaste,
  ListChecks,
  BookMarked,
  ShieldCheck,
  Check,
  ArrowRight,
} from "lucide-react";
import { PublicNav } from "@/components/PublicNav";
import { LinkButton } from "@/components/Button";
import { PLANS } from "@/lib/plan";

const FEATURES = [
  {
    icon: ClipboardPaste,
    title: "Paste, don't type",
    body: "Any transcript — Zoom, Meet, a dictated voice memo — becomes a clean write-up in seconds.",
  },
  {
    icon: ListChecks,
    title: "Action items that stick",
    body: "Tasks mentioned in the conversation get pulled out automatically into a checklist you can close out.",
  },
  {
    icon: BookMarked,
    title: "A record for every meeting",
    body: "Nothing lives in a doc that gets buried. Every write-up is saved to your account and easy to find later.",
  },
  {
    icon: ShieldCheck,
    title: "Kept behind a real login",
    body: "Transcripts and notes are stored per account, not shared state that resets when the tab reloads.",
  },
];

const STEPS = [
  { n: "01", title: "Paste your transcript", body: "Drop in raw text from any meeting tool, or type up rough notes as you go." },
  { n: "02", title: "Get notes back in seconds", body: "A short summary and a list of action items, generated and filed automatically." },
  { n: "03", title: "Check things off as you go", body: "Come back anytime — every meeting is in your history, searchable by title." },
];

export default function LandingPage() {
  return (
    <div className="flex min-h-full flex-col">
      <PublicNav />

      <main className="flex-1">
        {/* Hero */}
        <section className="mx-auto grid max-w-6xl gap-14 px-6 py-20 md:grid-cols-2 md:items-center md:py-28">
          <div>
            <p className="mb-5 font-mono text-xs tracking-[0.2em] text-brass uppercase">
              AI meeting notes
            </p>
            <h1 className="font-display text-4xl leading-[1.08] text-text sm:text-5xl">
              Every meeting gets a <em className="text-brass-bright">paper trail.</em>
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-text-muted">
              Paste a transcript. Get a clean summary and action items back in
              seconds — filed under your account, searchable, and never lost
              in a doc again.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <LinkButton href="/signup" size="lg">
                Start free <ArrowRight className="h-4 w-4" />
              </LinkButton>
              <LinkButton href="#pricing" variant="secondary" size="lg">
                See pricing
              </LinkButton>
            </div>
            <p className="mt-4 text-sm text-text-muted">
              Free for 3 write-ups a day. No card required to start.
            </p>
          </div>

          <LedgerMock />
        </section>

        {/* Features */}
        <section className="border-t border-rule">
          <div className="mx-auto max-w-6xl px-6 py-20">
            <h2 className="max-w-lg font-display text-3xl text-text">
              Built for the meeting you just had, not the tool you have to
              learn.
            </h2>
            <div className="mt-12 grid gap-10 sm:grid-cols-2">
              {FEATURES.map((f) => (
                <div key={f.title} className="flex gap-4">
                  <f.icon className="mt-0.5 h-5 w-5 flex-shrink-0 text-brass" />
                  <div>
                    <h3 className="font-medium text-text">{f.title}</h3>
                    <p className="mt-1.5 text-[0.95rem] leading-relaxed text-text-muted">
                      {f.body}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="border-t border-rule bg-ink-raised/40">
          <div className="mx-auto max-w-6xl px-6 py-20">
            <h2 className="font-display text-3xl text-text">How it works</h2>
            <div className="mt-12 grid gap-10 sm:grid-cols-3">
              {STEPS.map((s) => (
                <div key={s.n}>
                  <p className="font-mono text-sm text-brass">{s.n}</p>
                  <h3 className="mt-3 font-medium text-text">{s.title}</h3>
                  <p className="mt-1.5 text-[0.95rem] leading-relaxed text-text-muted">
                    {s.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="border-t border-rule">
          <div className="mx-auto max-w-6xl px-6 py-20">
            <h2 className="font-display text-3xl text-text">
              Simple pricing, cancel anytime.
            </h2>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 sm:max-w-2xl">
              <PlanCard plan="free" />
              <PlanCard plan="pro" featured />
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="border-t border-rule">
          <div className="mx-auto max-w-6xl px-6 py-20 text-center">
            <h2 className="font-display text-3xl text-text">
              Stop losing meetings to a doc that gets buried.
            </h2>
            <div className="mt-8">
              <LinkButton href="/signup" size="lg">
                Start free <ArrowRight className="h-4 w-4" />
              </LinkButton>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-rule">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-6 py-10 text-sm text-text-muted sm:flex-row sm:items-center sm:justify-between">
          <span className="font-display text-text">Minutes</span>
          <span>© {new Date().getFullYear()} Minutes. A record for every meeting.</span>
        </div>
      </footer>
    </div>
  );
}

function PlanCard({ plan, featured }: { plan: "free" | "pro"; featured?: boolean }) {
  const p = PLANS[plan];
  return (
    <div
      className={`flex flex-col rounded-sm border p-7 ${
        featured ? "border-brass bg-ink-raised" : "border-rule"
      }`}
    >
      {featured && (
        <span className="mb-4 inline-flex w-fit items-center rounded-sm bg-brass px-2.5 py-1 font-mono text-xs uppercase tracking-wide text-ink">
          Recommended
        </span>
      )}
      <h3 className="font-display text-xl text-text">{p.label}</h3>
      <p className="mt-2 font-mono text-2xl text-text">{p.priceLabel}</p>
      <ul className="mt-6 flex-1 space-y-3">
        {p.features.map((f) => (
          <li key={f} className="flex items-start gap-2.5 text-sm text-text-muted">
            <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-brass" />
            {f}
          </li>
        ))}
      </ul>
      <LinkButton
        href="/signup"
        variant={featured ? "primary" : "secondary"}
        className="mt-7 w-full"
      >
        {plan === "pro" ? "Go Pro" : "Start free"}
      </LinkButton>
    </div>
  );
}

function LedgerMock() {
  return (
    <div className="rounded-sm border border-rule bg-ink-raised p-6 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.6)]">
      <p className="font-mono text-[0.7rem] uppercase tracking-widest text-text-muted">
        Transcript
      </p>
      <div className="mt-3 space-y-1.5 font-mono text-[0.78rem] leading-relaxed text-text-muted/70">
        <p>Priya: —so the onboarding drop-off is still around 40%...</p>
        <p>Sam: yeah I think it&apos;s the email verification step.</p>
        <p>Priya: can you pull the funnel numbers by Thursday?</p>
        <p>Sam: sure, I&apos;ll send it before the next sync.</p>
      </div>

      <div className="my-6 border-t border-dashed border-rule" />

      <p className="font-mono text-[0.7rem] uppercase tracking-widest text-brass">
        Minutes — onboarding drop-off review
      </p>
      <p className="mt-3 text-sm leading-relaxed text-text">
        Team reviewed the 40% onboarding drop-off. Email verification is the
        suspected cause; Sam will pull funnel data before the next sync.
      </p>
      <ul className="mt-4 space-y-2 text-sm text-text">
        <li className="flex items-center gap-2.5">
          <span className="flex h-4 w-4 items-center justify-center rounded-[3px] border border-good bg-good/20">
            <Check className="h-3 w-3 text-good" />
          </span>
          <span className="text-text-muted line-through">
            Pull funnel numbers by Thursday — Sam
          </span>
        </li>
        <li className="flex items-center gap-2.5">
          <span className="h-4 w-4 rounded-[3px] border border-rule" />
          Review email verification copy — Priya
        </li>
      </ul>
    </div>
  );
}
