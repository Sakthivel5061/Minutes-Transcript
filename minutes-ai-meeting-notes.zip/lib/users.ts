import { query, queryOne } from "@/lib/db";

export type Plan = "free" | "pro";

export interface User {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  plan: Plan;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  stripe_subscription_status: string | null;
  stripe_current_period_end: string | null;
  created_at: string;
}

export type PublicUser = Omit<User, "password_hash">;

export function toPublicUser(user: User): PublicUser {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { password_hash, ...rest } = user;
  return rest;
}

export async function getUserByEmail(email: string): Promise<User | null> {
  return queryOne<User>("SELECT * FROM users WHERE email = $1", [
    email.trim().toLowerCase(),
  ]);
}

export async function getUserById(id: string): Promise<User | null> {
  return queryOne<User>("SELECT * FROM users WHERE id = $1", [id]);
}

export async function createUser(params: {
  name: string;
  email: string;
  passwordHash: string;
}): Promise<User> {
  const row = await queryOne<User>(
    `INSERT INTO users (name, email, password_hash)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [params.name.trim(), params.email.trim().toLowerCase(), params.passwordHash]
  );
  if (!row) throw new Error("Failed to create user");
  return row;
}

export async function getUserByStripeCustomerId(
  customerId: string
): Promise<User | null> {
  return queryOne<User>("SELECT * FROM users WHERE stripe_customer_id = $1", [
    customerId,
  ]);
}

export async function setStripeCustomerId(
  userId: string,
  stripeCustomerId: string
): Promise<void> {
  await query("UPDATE users SET stripe_customer_id = $1 WHERE id = $2", [
    stripeCustomerId,
    userId,
  ]);
}

export async function applySubscriptionUpdate(params: {
  stripeCustomerId: string;
  stripeSubscriptionId: string | null;
  status: string | null;
  currentPeriodEnd: Date | null;
  plan: Plan;
}): Promise<void> {
  await query(
    `UPDATE users
     SET plan = $1,
         stripe_subscription_id = $2,
         stripe_subscription_status = $3,
         stripe_current_period_end = $4
     WHERE stripe_customer_id = $5`,
    [
      params.plan,
      params.stripeSubscriptionId,
      params.status,
      params.currentPeriodEnd,
      params.stripeCustomerId,
    ]
  );
}
