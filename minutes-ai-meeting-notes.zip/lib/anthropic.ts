import "server-only";
import Anthropic from "@anthropic-ai/sdk";

export interface MeetingNotes {
  title: string;
  summary: string;
  actionItems: string[];
}

const NOTES_TOOL = {
  name: "record_meeting_notes",
  description:
    "Record the structured summary and action items extracted from a meeting transcript.",
  input_schema: {
    type: "object" as const,
    properties: {
      title: {
        type: "string" as const,
        description:
          "A short, specific title for this meeting (roughly 4-8 words), based on what it was actually about.",
      },
      summary: {
        type: "string" as const,
        description:
          "A concise 3-6 sentence summary covering what was discussed and any decisions made. Plain prose, no headers.",
      },
      action_items: {
        type: "array" as const,
        items: { type: "string" as const },
        description:
          "Concrete action items mentioned or clearly implied, each a short imperative task (include an owner's name if one was mentioned). Empty array if the transcript has none.",
      },
    },
    required: ["title", "summary", "action_items"],
  },
};

let _client: Anthropic | null = null;
function client(): Anthropic {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error(
      "ANTHROPIC_API_KEY is not set. Add it to .env (see .env.example)."
    );
  }
  _client ??= new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return _client;
}

function isToolUseBlock(
  block: Anthropic.ContentBlock
): block is Anthropic.ToolUseBlock {
  return block.type === "tool_use";
}

/**
 * Sends a transcript to Claude and returns a structured title, summary, and
 * action item list. Thinking is disabled and the tool call is forced so the
 * response is always structured data, never free-form prose.
 */
export async function generateMeetingNotes(
  transcript: string
): Promise<MeetingNotes> {
  const message = await client().messages.create({
    model: "claude-sonnet-5",
    max_tokens: 2048,
    thinking: { type: "disabled" },
    output_config: { effort: "medium" },
    system:
      "You turn raw meeting transcripts into structured notes for a meeting-notes product. " +
      "Read the transcript below and call record_meeting_notes exactly once. Be faithful to " +
      "what was actually said — do not invent decisions or action items that aren't supported " +
      "by the transcript. If the transcript is fragmentary or unclear, summarize what's there " +
      "and note the gaps rather than guessing.",
    messages: [{ role: "user", content: transcript }],
    tools: [NOTES_TOOL],
    tool_choice: { type: "tool", name: "record_meeting_notes" },
  });

  const toolUse = message.content.find(isToolUseBlock);
  if (!toolUse) {
    throw new Error(
      "Claude didn't return structured notes for this transcript. Please try again."
    );
  }

  const input = toolUse.input as {
    title?: string;
    summary?: string;
    action_items?: string[];
  };

  return {
    title: input.title?.trim() || "Untitled meeting",
    summary: input.summary?.trim() || "",
    actionItems: Array.isArray(input.action_items)
      ? input.action_items.map((s) => s.trim()).filter(Boolean)
      : [],
  };
}
