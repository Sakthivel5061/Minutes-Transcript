import "server-only";
import Stripe from "stripe";

let _stripe: Stripe | null = null;

/** Lazily-constructed Stripe client so the app can still boot without a key set. */
export function stripe(): Stripe {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error(
      "STRIPE_SECRET_KEY is not set. Add it to .env (see .env.example)."
    );
  }
  _stripe ??= new Stripe(process.env.STRIPE_SECRET_KEY);
  return _stripe;
}

export const PRO_PRICE_ID = process.env.STRIPE_PRO_PRICE_ID ?? "";
