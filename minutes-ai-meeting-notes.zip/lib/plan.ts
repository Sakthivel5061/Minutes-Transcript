import { query } from "@/lib/db";
import type { Plan, User } from "@/lib/users";

export const PLANS: Record<
  Plan,
  {
    label: string;
    priceLabel: string;
    dailyMeetingLimit: number | null; // null = unlimited
    features: string[];
  }
> = {
  free: {
    label: "Starter",
    priceLabel: "Free",
    dailyMeetingLimit: 3,
    features: [
      "3 meeting write-ups a day",
      "AI summary + action items",
      "Searchable meeting history",
    ],
  },
  pro: {
    label: "Pro",
    priceLabel: "$15/mo",
    dailyMeetingLimit: null,
    features: [
      "Unlimited meeting write-ups",
      "Everything in Starter",
      "Priority email support",
      "Cancel anytime",
    ],
  },
};

export async function countMeetingsToday(userId: string): Promise<number> {
  const rows = await query<{ count: string }>(
    `SELECT COUNT(*)::text AS count
     FROM meetings
     WHERE user_id = $1
       AND created_at >= date_trunc('day', now())`,
    [userId]
  );
  return Number(rows[0]?.count ?? 0);
}

export interface UsageStatus {
  plan: Plan;
  used: number;
  limit: number | null;
  remaining: number | null;
  canCreate: boolean;
}

export async function getUsageStatus(user: User): Promise<UsageStatus> {
  const limit = PLANS[user.plan].dailyMeetingLimit;
  const used = await countMeetingsToday(user.id);
  const remaining = limit === null ? null : Math.max(limit - used, 0);
  return {
    plan: user.plan,
    used,
    limit,
    remaining,
    canCreate: limit === null || used < limit,
  };
}
