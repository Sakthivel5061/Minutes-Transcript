import { Pool, type QueryResultRow } from "pg";

// Reused across hot-reloads in dev so we don't exhaust connections.
declare global {
  var __pgPool: Pool | undefined;
}

function createPool() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error(
      "DATABASE_URL is not set. Copy .env.example to .env and fill it in."
    );
  }
  return new Pool({
    connectionString,
    max: 10,
    ssl:
      process.env.PGSSL === "false"
        ? false
        : connectionString.includes("localhost") ||
            connectionString.includes("127.0.0.1")
          ? false
          : { rejectUnauthorized: false },
  });
}

export const pool = globalThis.__pgPool ?? createPool();
if (process.env.NODE_ENV !== "production") {
  globalThis.__pgPool = pool;
}

export async function query<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params: unknown[] = []
): Promise<T[]> {
  const result = await pool.query<T>(text, params);
  return result.rows;
}

export async function queryOne<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params: unknown[] = []
): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows[0] ?? null;
}
