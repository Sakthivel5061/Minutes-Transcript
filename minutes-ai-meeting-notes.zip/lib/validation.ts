import { z } from "zod";

export const signupSchema = z.object({
  name: z.string().trim().min(1, "Enter your name").max(100),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(8, "Use at least 8 characters"),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

export const MIN_TRANSCRIPT_LENGTH = 40;
export const MAX_TRANSCRIPT_LENGTH = 60_000;

export const createMeetingSchema = z.object({
  transcript: z
    .string()
    .trim()
    .min(
      MIN_TRANSCRIPT_LENGTH,
      `Paste a bit more — at least ${MIN_TRANSCRIPT_LENGTH} characters of transcript.`
    )
    .max(
      MAX_TRANSCRIPT_LENGTH,
      `That transcript is longer than ${MAX_TRANSCRIPT_LENGTH.toLocaleString()} characters. Trim it down and try again.`
    ),
});

/** Formats a ZodError into a single human-readable message for API responses. */
export function firstIssueMessage(error: z.ZodError): string {
  return error.issues[0]?.message ?? "Invalid input.";
}
