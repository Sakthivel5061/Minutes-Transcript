import { pool, query, queryOne } from "@/lib/db";
import type { MeetingNotes } from "@/lib/anthropic";

export interface Meeting {
  id: string;
  user_id: string;
  title: string;
  transcript: string;
  summary: string;
  created_at: string;
}

export interface ActionItem {
  id: string;
  meeting_id: string;
  text: string;
  done: boolean;
  position: number;
}

export type MeetingWithItems = Meeting & { action_items: ActionItem[] };

export async function listMeetingsForUser(userId: string): Promise<Meeting[]> {
  return query<Meeting>(
    `SELECT id, user_id, title, transcript, summary, created_at
     FROM meetings
     WHERE user_id = $1
     ORDER BY created_at DESC`,
    [userId]
  );
}

export async function getMeetingWithItems(
  meetingId: string,
  userId: string
): Promise<MeetingWithItems | null> {
  const meeting = await queryOne<Meeting>(
    `SELECT id, user_id, title, transcript, summary, created_at
     FROM meetings WHERE id = $1 AND user_id = $2`,
    [meetingId, userId]
  );
  if (!meeting) return null;

  const actionItems = await query<ActionItem>(
    `SELECT id, meeting_id, text, done, position
     FROM action_items WHERE meeting_id = $1 ORDER BY position ASC`,
    [meetingId]
  );

  return { ...meeting, action_items: actionItems };
}

/** Creates a meeting and its action items inside a single transaction. */
export async function createMeeting(
  userId: string,
  transcript: string,
  notes: MeetingNotes
): Promise<MeetingWithItems> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const meetingResult = await client.query<Meeting>(
      `INSERT INTO meetings (user_id, title, transcript, summary)
       VALUES ($1, $2, $3, $4)
       RETURNING id, user_id, title, transcript, summary, created_at`,
      [userId, notes.title, transcript, notes.summary]
    );
    const meeting = meetingResult.rows[0];

    const actionItems: ActionItem[] = [];
    for (let i = 0; i < notes.actionItems.length; i++) {
      const itemResult = await client.query<ActionItem>(
        `INSERT INTO action_items (meeting_id, text, position)
         VALUES ($1, $2, $3)
         RETURNING id, meeting_id, text, done, position`,
        [meeting.id, notes.actionItems[i], i]
      );
      actionItems.push(itemResult.rows[0]);
    }

    await client.query("COMMIT");
    return { ...meeting, action_items: actionItems };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

/** Toggles an action item's done state. Scoped by user via a join, so one
 * user can never flip another user's checklist. */
export async function toggleActionItem(
  itemId: string,
  userId: string
): Promise<ActionItem | null> {
  return queryOne<ActionItem>(
    `UPDATE action_items
     SET done = NOT done
     WHERE id = $1
       AND meeting_id IN (SELECT id FROM meetings WHERE user_id = $2)
     RETURNING id, meeting_id, text, done, position`,
    [itemId, userId]
  );
}
