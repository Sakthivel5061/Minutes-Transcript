import { NextResponse, type NextRequest } from "next/server";

// This only smooths the UX (bounce logged-out visitors away from app pages,
// bounce logged-in visitors away from /login and /signup). It is NOT the
// security boundary — middleware can be bypassed (see CVE-2025-29927), so
// every protected Server Component and Route Handler independently calls
// getCurrentUser()/getCurrentUserId() from lib/auth.ts before touching data.
const PROTECTED_PREFIXES = ["/dashboard", "/billing"];
const AUTH_PAGES = ["/login", "/signup"];
const SESSION_COOKIE = "minutes_session";

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasSessionCookie = Boolean(request.cookies.get(SESSION_COOKIE)?.value);

  if (
    PROTECTED_PREFIXES.some((p) => pathname.startsWith(p)) &&
    !hasSessionCookie
  ) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  if (AUTH_PAGES.includes(pathname) && hasSessionCookie) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/billing/:path*", "/login", "/signup"],
};
