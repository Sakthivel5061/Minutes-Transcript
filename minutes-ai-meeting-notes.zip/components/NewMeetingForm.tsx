"use client";

import { useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Upload } from "lucide-react";
import { Button } from "@/components/Button";
import { MAX_TRANSCRIPT_LENGTH, MIN_TRANSCRIPT_LENGTH } from "@/lib/validation";

export function NewMeetingForm({ disabled }: { disabled?: boolean }) {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setTranscript(String(reader.result ?? ""));
    reader.readAsText(file);
    e.target.value = "";
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (transcript.trim().length < MIN_TRANSCRIPT_LENGTH) {
      setError(`Paste a bit more — at least ${MIN_TRANSCRIPT_LENGTH} characters.`);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/meetings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Something went wrong. Please try again.");
        setLoading(false);
        return;
      }

      router.push(`/dashboard/${data.meeting.id}`);
      router.refresh();
    } catch {
      setError("Couldn't reach the server. Check your connection and try again.");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="rounded-sm border border-rule bg-ink-raised p-5">
        <div className="mb-3 flex items-center justify-between">
          <label htmlFor="transcript" className="text-sm text-text-muted">
            Paste a transcript
          </label>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 text-sm text-text-muted hover:text-brass-bright"
          >
            <Upload className="h-3.5 w-3.5" />
            Upload .txt
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,text/plain"
            onChange={handleFile}
            className="hidden"
          />
        </div>
        <textarea
          id="transcript"
          value={transcript}
          onChange={(e) => setTranscript(e.target.value)}
          maxLength={MAX_TRANSCRIPT_LENGTH}
          rows={9}
          placeholder="Priya: So the onboarding drop-off is still around 40%...&#10;Sam: Yeah, I think it's the email verification step..."
          className="w-full resize-y rounded-sm border border-rule bg-ink px-3.5 py-3 font-mono text-[0.85rem] leading-relaxed text-text placeholder:text-text-muted/40 focus:border-brass focus:outline-none"
        />
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-text-muted">
            {transcript.length.toLocaleString()} / {MAX_TRANSCRIPT_LENGTH.toLocaleString()}
          </span>
        </div>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-sm text-ledger-red">
          {error}{" "}
          {error.toLowerCase().includes("upgrade") && (
            <a href="/billing" className="underline hover:text-brass-bright">
              Go to billing
            </a>
          )}
        </p>
      )}

      <Button type="submit" disabled={loading || disabled} className="mt-4">
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        {loading ? "Generating notes…" : "Generate notes"}
      </Button>
    </form>
  );
}
