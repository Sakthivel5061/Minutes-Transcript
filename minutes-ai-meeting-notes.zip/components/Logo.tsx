import Link from "next/link";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link
      href="/"
      className={`inline-flex items-center gap-2 font-display text-xl text-text ${className}`}
    >
      <span className="inline-block h-2.5 w-2.5 rounded-full bg-brass" aria-hidden />
      Minutes
    </Link>
  );
}
