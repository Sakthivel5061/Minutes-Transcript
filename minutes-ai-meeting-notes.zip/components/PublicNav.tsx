import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { LinkButton } from "@/components/Button";

export async function PublicNav() {
  const user = await getCurrentUser();

  return (
    <header className="border-b border-rule">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Logo />
        <nav className="flex items-center gap-6">
          <Link
            href="/#pricing"
            className="hidden text-sm text-text-muted hover:text-text sm:inline"
          >
            Pricing
          </Link>
          {user ? (
            <LinkButton href="/dashboard" size="sm">
              Go to dashboard
            </LinkButton>
          ) : (
            <>
              <Link
                href="/login"
                className="hidden text-sm text-text-muted hover:text-text sm:inline"
              >
                Log in
              </Link>
              <LinkButton href="/signup" size="sm">
                Start free
              </LinkButton>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
