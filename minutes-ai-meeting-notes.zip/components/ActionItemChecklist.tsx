"use client";

import { useState } from "react";
import { Check } from "lucide-react";
import type { ActionItem } from "@/lib/meetings";

export function ActionItemChecklist({
  meetingId,
  items,
}: {
  meetingId: string;
  items: ActionItem[];
}) {
  const [state, setState] = useState(items);
  const [pending, setPending] = useState<string | null>(null);

  async function toggle(itemId: string) {
    // Optimistic update, rolled back on failure.
    const previous = state;
    setState((s) =>
      s.map((it) => (it.id === itemId ? { ...it, done: !it.done } : it))
    );
    setPending(itemId);

    try {
      const res = await fetch(
        `/api/meetings/${meetingId}/action-items/${itemId}`,
        { method: "PATCH" }
      );
      if (!res.ok) throw new Error("failed");
    } catch {
      setState(previous);
    } finally {
      setPending(null);
    }
  }

  if (state.length === 0) {
    return (
      <p className="text-sm text-text-muted">
        No action items were found in this transcript.
      </p>
    );
  }

  return (
    <ul className="space-y-2.5">
      {state.map((item) => (
        <li key={item.id}>
          <button
            type="button"
            onClick={() => toggle(item.id)}
            disabled={pending === item.id}
            className="flex w-full items-start gap-3 rounded-sm px-1 py-1 text-left hover:bg-ink-raised disabled:opacity-60"
          >
            <span
              className={`mt-0.5 flex h-[18px] w-[18px] flex-shrink-0 items-center justify-center rounded-[3px] border ${
                item.done ? "border-good bg-good/20" : "border-rule"
              }`}
            >
              {item.done && <Check className="h-3 w-3 text-good" />}
            </span>
            <span className={item.done ? "text-text-muted line-through" : "text-text"}>
              {item.text}
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}
