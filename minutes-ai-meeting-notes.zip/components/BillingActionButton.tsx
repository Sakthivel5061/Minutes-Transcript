"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/Button";

export function BillingActionButton({
  endpoint,
  children,
  variant = "primary",
}: {
  endpoint: "/api/stripe/checkout" | "/api/stripe/portal";
  children: React.ReactNode;
  variant?: "primary" | "secondary";
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(endpoint, { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.url) {
        setError(data.error ?? "Something went wrong. Please try again.");
        setLoading(false);
        return;
      }
      window.location.href = data.url;
    } catch {
      setError("Couldn't reach the server. Check your connection and try again.");
      setLoading(false);
    }
  }

  return (
    <div>
      <Button onClick={handleClick} disabled={loading} variant={variant}>
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        {children}
      </Button>
      {error && <p className="mt-2 text-sm text-ledger-red">{error}</p>}
    </div>
  );
}
