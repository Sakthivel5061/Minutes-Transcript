-- Minutes — database schema
-- Run via `npm run db:migrate` (see db/migrate.mjs). Safe to re-run: every
-- statement is idempotent (IF NOT EXISTS / CREATE OR REPLACE).

CREATE TABLE IF NOT EXISTS users (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                        TEXT NOT NULL,
  email                       TEXT NOT NULL UNIQUE,
  password_hash               TEXT NOT NULL,
  plan                        TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'pro')),
  stripe_customer_id          TEXT UNIQUE,
  stripe_subscription_id      TEXT UNIQUE,
  stripe_subscription_status  TEXT,
  stripe_current_period_end   TIMESTAMPTZ,
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meetings (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  transcript   TEXT NOT NULL,
  summary      TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS action_items (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id   UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  text         TEXT NOT NULL,
  done         BOOLEAN NOT NULL DEFAULT false,
  position     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_meetings_user_created ON meetings (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_action_items_meeting ON action_items (meeting_id, position);
