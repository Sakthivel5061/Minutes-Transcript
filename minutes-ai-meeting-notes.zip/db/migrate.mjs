// Applies db/schema.sql to whatever DATABASE_URL points at.
// Usage: node --env-file=.env db/migrate.mjs
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { Client } from "pg";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    console.error("DATABASE_URL is not set. Add it to .env first.");
    process.exit(1);
  }

  const sql = readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  const client = new Client({ connectionString });

  await client.connect();
  console.log("Connected. Applying db/schema.sql ...");
  try {
    await client.query(sql);
    console.log("Migration complete.");
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
